import axios from 'axios';

const loginService = async (req, res)=>{
    axios.post('http://localhost:8080/signIn', {
        
    })
}