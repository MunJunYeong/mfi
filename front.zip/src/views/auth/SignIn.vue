<template>
  <v-container>
    <v-row justify="center">
      <v-col cols='4'>
        <div>
          <v-text-field
            label="아이디 입력"
            v-model="id"
            hide-details="auto"
          >
          </v-text-field>
          <v-text-field
            label="비밀번호 입력"
            v-model="pw"
            hide-details="auto"
            :type="show1 ? 'text' : 'password'"
            :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
            @click:append="show1 = !show1"
          >
          </v-text-field>
          <v-checkbox
          :label="`로그인상태유지`">
          </v-checkbox> 
          <!-- 로그인버튼 -->
          <v-btn
            elevation="2" block
            v-on:click="login"
            @keyup.enter="login"
          >로그인</v-btn>              
        </div>
      </v-col>
    </v-row>
    <br><br>
    <v-row justify="center">
      <v-col cols='4'>
        <div style="text-align: center;">
          <router-link to="/auth/findId">아이디찾기</router-link> ㅣ
          <router-link to="/auth/findPw">비밀번호찾기</router-link> ㅣ 
          <router-link to="/auth/signUp">회원가입</router-link>
        </div>
      </v-col>
    </v-row>
    <br><br>
    <v-row justify="center">
      <v-col cols='4'>
        <div style="text-align: center;">© 2021 MetaphorForInvesting.com. All rights reserved.</div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
  // import axios from 'axios';

  export default {
    name: 'SignIn',
    
    props : {
      
    },
    data() {
      return{
        id : '',
        pw : '',
        show1: false, show2 : false,
      }
    },
    methods: {
      async login(){
        try {
          await this.$store.dispatch('auth_login', {
            id : this.id,
            pw : this.pw
          })
        } catch (err) {
          console.log(err)
          if(err.message === 'wrongPw'){
            alert('비밀번호가 틀렸습니다.')
          }else if(err.message === 'wrongId'){
            alert('아이디가 존재하지 않습니다.')
          }else if(err.message === 'wrongData'){
            alert('아이디와 비밀번호를 둘다 입력해주세요..')
          }else{
            alert('통신 오류')
          }
        }
      }
    },
  }
</script>
