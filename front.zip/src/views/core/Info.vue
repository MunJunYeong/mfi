<template>
    <div>
        dfas
    </div>    
</template>
<script>
export default {
    name : 'info',
}
</script>